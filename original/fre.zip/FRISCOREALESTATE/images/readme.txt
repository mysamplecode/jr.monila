button text: Submit
primary color: 000000
gradient color: ffffff
width (pixels): 70
height (pixels): 30
corner radius (pixels): 10
text height (points): 10
text color: d6d6d6
background color: clear
font name: DejaVuSansCondensed-Bold
rollover primary color: ffff00
rollover gradient color: 6666ff
rollover text color: 000000
quality: 3
image location: none
image height (pixels): 12
image name: 
image foreground color determination: auto
image foreground color: 000000
image transparent color determination: auto
image transparent color: ffffff
url: http://www.glassybuttons.com/buttonmill/glassy.php?button_text=Submit&color=000000&grcolor=ffffff&width=70&height=30&radius=10&theight=10&tcolor=d6d6d6&bkcolor=clear&fname=DejaVuSansCondensed-Bold&rcolor=ffff00&rgrcolor=6666ff&rtcolor=000000&imglocate=none&imgheight=12&imgname=&imgfore=auto&imgforecolor=000000&imgtran=auto&imgtrancolor=ffffff&quality=3&fromhere=1
